%Routine which gives the boundary_data value at position coords

function boundary_value = boundary_data(coords)

boundary_value = 0;

end