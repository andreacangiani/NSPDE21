%Function which returns the value of the source data at position
%coords

function source = source_data(coords)

source = 10;

end